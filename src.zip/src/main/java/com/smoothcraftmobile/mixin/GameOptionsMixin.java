package com.smoothcraftmobile.mixin;

import com.smoothcraftmobile.SmoothCraftMobileClient;
import net.minecraft.client.option.GameOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameOptions.class)
public abstract class GameOptionsMixin {
    
    @Inject(method = "write", at = @At("HEAD"))
    private void onOptionsWrite(CallbackInfo ci) {
        SmoothCraftMobileClient instance = SmoothCraftMobileClient.getInstance();
        if (instance != null && instance.getConfig() != null) {
            instance.getConfig().save();
        }
    }
}
