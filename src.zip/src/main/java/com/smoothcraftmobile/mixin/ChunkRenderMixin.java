package com.smoothcraftmobile.mixin;

import com.smoothcraftmobile.SmoothCraftMobileClient;
import com.smoothcraftmobile.optimization.ChunkOptimizer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChunkBuilder.BuiltChunk.class)
public abstract class ChunkRenderMixin {
    
    @Inject(method = "scheduleRebuild(Z)V", at = @At("HEAD"), cancellable = true)
    private void onScheduleRebuild(boolean urgent, CallbackInfo ci) {
        SmoothCraftMobileClient instance = SmoothCraftMobileClient.getInstance();
        if (instance == null) return;
        
        ChunkOptimizer optimizer = instance.getChunkOptimizer();
        if (optimizer != null && !urgent && optimizer.shouldThrottleChunkBuild()) {
            ci.cancel();
        }
    }
}
