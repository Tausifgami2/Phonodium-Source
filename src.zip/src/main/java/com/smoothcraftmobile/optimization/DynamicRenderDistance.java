package com.smoothcraftmobile.optimization;

import com.smoothcraftmobile.SmoothCraftMobileClient;
import com.smoothcraftmobile.config.ModConfig;
import net.minecraft.client.MinecraftClient;

public class DynamicRenderDistance {
    private final ModConfig config;
    private final PerformanceMonitor performanceMonitor;
    private final DeviceDetector deviceDetector;
    
    private int currentRenderDistance;
    private int targetRenderDistance;
    private long lastAdjustment = 0;
    private static final long ADJUSTMENT_COOLDOWN = 2000;
    
    private int originalRenderDistance = -1;
    private boolean isActive = false;
    
    private int stableFrameCount = 0;
    private static final int STABILITY_THRESHOLD = 60;
    
    public DynamicRenderDistance(ModConfig config, PerformanceMonitor performanceMonitor, DeviceDetector deviceDetector) {
        this.config = config;
        this.performanceMonitor = performanceMonitor;
        this.deviceDetector = deviceDetector;
        this.currentRenderDistance = config.getMaxRenderDistance();
        this.targetRenderDistance = currentRenderDistance;
    }
    
    public void tick(MinecraftClient client) {
        if (!config.isDynamicRenderDistanceEnabled()) {
            if (isActive && originalRenderDistance > 0) {
                client.options.getViewDistance().setValue(originalRenderDistance);
                isActive = false;
            }
            return;
        }
        
        if (!isActive) {
            originalRenderDistance = client.options.getViewDistance().getValue();
            currentRenderDistance = originalRenderDistance;
            targetRenderDistance = originalRenderDistance;
            isActive = true;
        }
        
        calculateTargetRenderDistance();
        
        applyRenderDistance(client);
    }
    
    private void calculateTargetRenderDistance() {
        int currentFPS = performanceMonitor.getCurrentFPS();
        int targetFPS = config.getTargetFPS();
        boolean stuttering = performanceMonitor.isStuttering();
        double cpuLoad = performanceMonitor.getCpuLoad();
        
        if (stuttering || cpuLoad > 0.95 || currentFPS < targetFPS * 0.5) {
            targetRenderDistance = Math.max(
                    config.getMinRenderDistance(),
                    currentRenderDistance - 2
            );
            stableFrameCount = 0;
        } else if (currentFPS < targetFPS * 0.8) {
            targetRenderDistance = Math.max(
                    config.getMinRenderDistance(),
                    currentRenderDistance - 1
            );
            stableFrameCount = 0;
        } else if (currentFPS >= targetFPS && cpuLoad < 0.7 && !stuttering) {
            stableFrameCount++;
            
            if (stableFrameCount >= STABILITY_THRESHOLD) {
                targetRenderDistance = Math.min(
                        config.getMaxRenderDistance(),
                        currentRenderDistance + 1
                );
            }
        } else {
            stableFrameCount = Math.max(0, stableFrameCount - 1);
        }
        
        long memoryAvailable = deviceDetector.getAvailableMemoryMB();
        if (memoryAvailable < 256) {
            targetRenderDistance = Math.min(targetRenderDistance, config.getMinRenderDistance() + 2);
        } else if (memoryAvailable < 512) {
            targetRenderDistance = Math.min(targetRenderDistance, (config.getMinRenderDistance() + config.getMaxRenderDistance()) / 2);
        }
    }
    
    private void applyRenderDistance(MinecraftClient client) {
        if (targetRenderDistance == currentRenderDistance) return;
        
        long now = System.currentTimeMillis();
        if (now - lastAdjustment < ADJUSTMENT_COOLDOWN) {
            if (!performanceMonitor.isPerformanceCritical()) {
                return;
            }
        }
        
        if (targetRenderDistance < currentRenderDistance) {
            currentRenderDistance--;
            lastAdjustment = now;
            client.options.getViewDistance().setValue(currentRenderDistance);
            SmoothCraftMobileClient.LOGGER.debug("Decreased render distance to {}", currentRenderDistance);
        } else if (targetRenderDistance > currentRenderDistance) {
            currentRenderDistance++;
            lastAdjustment = now;
            stableFrameCount = 0;
            client.options.getViewDistance().setValue(currentRenderDistance);
            SmoothCraftMobileClient.LOGGER.debug("Increased render distance to {}", currentRenderDistance);
        }
    }
    
    public int getCurrentRenderDistance() {
        return currentRenderDistance;
    }
    
    public int getTargetRenderDistance() {
        return targetRenderDistance;
    }
    
    public int getOriginalRenderDistance() {
        return originalRenderDistance;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void reset(MinecraftClient client) {
        if (originalRenderDistance > 0) {
            client.options.getViewDistance().setValue(originalRenderDistance);
            currentRenderDistance = originalRenderDistance;
            targetRenderDistance = originalRenderDistance;
        }
        stableFrameCount = 0;
        SmoothCraftMobileClient.LOGGER.info("Reset render distance to {}", originalRenderDistance);
    }
    
    public String getStatus() {
        return String.format("RD: %d/%d (target: %d) | Stable: %d/%d",
                currentRenderDistance, 
                config.getMaxRenderDistance(),
                targetRenderDistance,
                stableFrameCount, 
                STABILITY_THRESHOLD);
    }
}
