package com.smoothcraftmobile.optimization;

import com.smoothcraftmobile.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EntityOptimizer {
    private final ModConfig config;
    private final PerformanceMonitor performanceMonitor;
    
    private final Map<UUID, EntityRenderData> entityRenderCache = new HashMap<>();
    private int entitiesUpdatedThisTick = 0;
    private int tickCounter = 0;
    
    public EntityOptimizer(ModConfig config, PerformanceMonitor performanceMonitor) {
        this.config = config;
        this.performanceMonitor = performanceMonitor;
    }
    
    public void tick(MinecraftClient client) {
        tickCounter++;
        entitiesUpdatedThisTick = 0;
        
        if (tickCounter % 100 == 0) {
            cleanupCache();
        }
    }
    
    public boolean shouldCullEntity(Entity entity, MinecraftClient client) {
        if (!config.isEntityCullingEnabled()) return false;
        if (client.player == null || client.getCameraEntity() == null) return false;
        
        Entity cameraEntity = client.getCameraEntity();
        double distance = entity.squaredDistanceTo(cameraEntity);
        double cullDistanceSq = config.getEntityCullingDistance() * config.getEntityCullingDistance();
        
        if (distance > cullDistanceSq) {
            return true;
        }
        
        if (distance > 64) {
            return !isInFieldOfView(entity, cameraEntity, client);
        }
        
        return false;
    }
    
    private boolean isInFieldOfView(Entity entity, Entity camera, MinecraftClient client) {
        Vec3d cameraPos = camera.getEyePos();
        Vec3d entityPos = entity.getPos().add(0, entity.getHeight() / 2, 0);
        Vec3d toEntity = entityPos.subtract(cameraPos).normalize();
        
        float yaw = camera.getYaw() * 0.017453292F;
        float pitch = camera.getPitch() * 0.017453292F;
        
        Vec3d lookDir = new Vec3d(
                -MathHelper.sin(yaw) * MathHelper.cos(pitch),
                -MathHelper.sin(pitch),
                MathHelper.cos(yaw) * MathHelper.cos(pitch)
        );
        
        double dot = lookDir.dotProduct(toEntity);
        double fovCos = Math.cos(Math.toRadians(client.options.getFov().getValue() * 0.6));
        
        return dot > fovCos;
    }
    
    public boolean shouldThrottleAnimation(Entity entity, MinecraftClient client) {
        if (!config.isAnimationThrottlingEnabled()) return false;
        if (client.player == null) return false;
        
        double distance = entity.squaredDistanceTo(client.player);
        double throttleDistanceSq = config.getAnimationThrottleDistance() * config.getAnimationThrottleDistance();
        
        if (distance <= throttleDistanceSq) return false;
        
        int throttleLevel = getThrottleLevel(entity, distance);
        
        return (tickCounter % throttleLevel) != 0;
    }
    
    private int getThrottleLevel(Entity entity, double distanceSq) {
        double distance = Math.sqrt(distanceSq);
        int throttleDistance = config.getAnimationThrottleDistance();
        
        int basePriority = getEntityPriority(entity);
        
        int distanceFactor = (int) Math.max(1, (distance - throttleDistance) / 8);
        
        return Math.min(20, basePriority + distanceFactor);
    }
    
    private int getEntityPriority(Entity entity) {
        if (entity instanceof PlayerEntity) {
            return 2;
        } else if (entity instanceof ArmorStandEntity) {
            return 6;
        } else if (entity instanceof ItemEntity) {
            return 8;
        } else if (entity instanceof ItemFrameEntity) {
            return 10;
        }
        return 4;
    }
    
    public boolean shouldUpdateEntity(Entity entity) {
        if (entitiesUpdatedThisTick >= config.getMaxEntityUpdatesPerTick()) {
            if (performanceMonitor.isPerformanceCritical()) {
                return false;
            }
        }
        
        entitiesUpdatedThisTick++;
        return true;
    }
    
    public float getEntityRenderScale(Entity entity, double distance) {
        if (distance < 16) return 1.0f;
        if (distance < 32) return 0.9f;
        if (distance < 48) return 0.75f;
        return 0.5f;
    }
    
    private void cleanupCache() {
        long now = System.currentTimeMillis();
        entityRenderCache.entrySet().removeIf(entry -> 
                now - entry.getValue().lastUpdate > 10000);
    }
    
    public int getEntitiesUpdatedThisTick() {
        return entitiesUpdatedThisTick;
    }
    
    public static class EntityRenderData {
        public boolean shouldRender = true;
        public float renderScale = 1.0f;
        public int throttleLevel = 1;
        public long lastUpdate = System.currentTimeMillis();
        
        public void update(boolean render, float scale, int throttle) {
            this.shouldRender = render;
            this.renderScale = scale;
            this.throttleLevel = throttle;
            this.lastUpdate = System.currentTimeMillis();
        }
    }
}
