package com.smoothcraftmobile.optimization;

import com.smoothcraftmobile.SmoothCraftMobileClient;
import com.smoothcraftmobile.config.ModConfig;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.atomic.AtomicInteger;

public class ChunkOptimizer {
    private final ModConfig config;
    private final PerformanceMonitor performanceMonitor;
    
    private final Deque<ChunkBuildTask> pendingBuilds = new ArrayDeque<>();
    private final AtomicInteger buildsThisFrame = new AtomicInteger(0);
    private int tickCounter = 0;
    
    private boolean throttlingActive = false;
    private int currentMaxBuildsPerFrame;
    private long lastThrottleAdjustment = 0;
    
    public ChunkOptimizer(ModConfig config, PerformanceMonitor performanceMonitor) {
        this.config = config;
        this.performanceMonitor = performanceMonitor;
        this.currentMaxBuildsPerFrame = config.getMaxChunkBuildsPerFrame();
    }
    
    public void tick(MinecraftClient client) {
        tickCounter++;
        buildsThisFrame.set(0);
        
        if (tickCounter % 20 == 0) {
            adjustThrottling();
        }
        
        processPendingBuilds();
    }
    
    private void adjustThrottling() {
        long now = System.currentTimeMillis();
        if (now - lastThrottleAdjustment < 500) return;
        lastThrottleAdjustment = now;
        
        double cpuLoad = performanceMonitor.getCpuLoad();
        boolean stuttering = performanceMonitor.isStuttering();
        int currentFPS = performanceMonitor.getCurrentFPS();
        int targetFPS = config.getTargetFPS();
        
        if (stuttering || cpuLoad > 0.9 || currentFPS < targetFPS * 0.7) {
            throttlingActive = true;
            currentMaxBuildsPerFrame = Math.max(1, currentMaxBuildsPerFrame - 1);
        } else if (cpuLoad < 0.7 && currentFPS > targetFPS && !stuttering) {
            currentMaxBuildsPerFrame = Math.min(
                    config.getMaxChunkBuildsPerFrame() * 2,
                    currentMaxBuildsPerFrame + 1
            );
            if (currentMaxBuildsPerFrame >= config.getMaxChunkBuildsPerFrame()) {
                throttlingActive = false;
            }
        }
    }
    
    private void processPendingBuilds() {
        int processed = 0;
        int maxToProcess = throttlingActive ? 
                Math.max(1, currentMaxBuildsPerFrame / 2) : 
                currentMaxBuildsPerFrame;
        
        while (!pendingBuilds.isEmpty() && processed < maxToProcess) {
            ChunkBuildTask task = pendingBuilds.pollFirst();
            if (task != null && task.isValid()) {
                processed++;
            }
        }
    }
    
    public boolean shouldThrottleChunkBuild() {
        if (!config.isChunkStreamingEnabled()) return false;
        
        if (performanceMonitor.isPerformanceCritical()) {
            return true;
        }
        
        return buildsThisFrame.get() >= currentMaxBuildsPerFrame;
    }
    
    public void onChunkBuildRequested(int chunkX, int chunkZ, boolean urgent) {
        if (!config.isChunkStreamingEnabled()) return;
        
        if (urgent || !shouldThrottleChunkBuild()) {
            buildsThisFrame.incrementAndGet();
            return;
        }
        
        pendingBuilds.addLast(new ChunkBuildTask(chunkX, chunkZ, System.currentTimeMillis()));
        
        if (pendingBuilds.size() > 256) {
            pendingBuilds.removeFirst();
        }
    }
    
    public int getPendingBuildCount() {
        return pendingBuilds.size();
    }
    
    public boolean isThrottlingActive() {
        return throttlingActive;
    }
    
    public int getCurrentMaxBuildsPerFrame() {
        return currentMaxBuildsPerFrame;
    }
    
    public void clearPendingBuilds() {
        pendingBuilds.clear();
        SmoothCraftMobileClient.LOGGER.info("Cleared {} pending chunk builds", pendingBuilds.size());
    }
    
    public static class ChunkBuildTask {
        private final int chunkX;
        private final int chunkZ;
        private final long timestamp;
        private static final long EXPIRY_TIME = 5000;
        
        public ChunkBuildTask(int chunkX, int chunkZ, long timestamp) {
            this.chunkX = chunkX;
            this.chunkZ = chunkZ;
            this.timestamp = timestamp;
        }
        
        public boolean isValid() {
            return System.currentTimeMillis() - timestamp < EXPIRY_TIME;
        }
        
        public int getChunkX() { return chunkX; }
        public int getChunkZ() { return chunkZ; }
    }
}
