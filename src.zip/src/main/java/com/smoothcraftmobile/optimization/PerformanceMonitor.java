package com.smoothcraftmobile.optimization;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayDeque;
import java.util.Deque;

public class PerformanceMonitor {
    private static final int FPS_SAMPLE_SIZE = 60;
    private static final int FRAME_TIME_SAMPLE_SIZE = 120;
    
    private final Deque<Integer> fpsHistory = new ArrayDeque<>(FPS_SAMPLE_SIZE);
    private final Deque<Long> frameTimeHistory = new ArrayDeque<>(FRAME_TIME_SAMPLE_SIZE);
    
    private long lastFrameNanoTime = System.nanoTime();
    private long lastFpsUpdate = System.currentTimeMillis();
    
    private volatile int currentFPS = 60;
    private volatile double averageFPS = 60.0;
    private volatile double frameTimeMs = 16.67;
    private volatile boolean isStuttering = false;
    private volatile double cpuLoad = 0.0;
    
    private static final long STUTTER_THRESHOLD_NANOS = 50_000_000L;
    private static final double TARGET_FRAME_TIME_MS = 16.67;
    private int stutterCount = 0;
    
    public void tick() {
    }
    
    public void onFrameRendered() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) {
            int mcFps = client.getCurrentFps();
            if (mcFps > 0) {
                currentFPS = mcFps;
            }
        }
        
        long now = System.nanoTime();
        long frameTime = now - lastFrameNanoTime;
        lastFrameNanoTime = now;
        
        frameTimeMs = frameTime / 1_000_000.0;
        
        frameTimeHistory.addLast(frameTime);
        if (frameTimeHistory.size() > FRAME_TIME_SAMPLE_SIZE) {
            frameTimeHistory.removeFirst();
        }
        
        if (frameTime > STUTTER_THRESHOLD_NANOS) {
            stutterCount++;
            if (stutterCount > 3) {
                isStuttering = true;
            }
        } else {
            stutterCount = Math.max(0, stutterCount - 1);
            if (stutterCount == 0) {
                isStuttering = false;
            }
        }
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFpsUpdate >= 1000) {
            fpsHistory.addLast(currentFPS);
            if (fpsHistory.size() > FPS_SAMPLE_SIZE) {
                fpsHistory.removeFirst();
            }
            
            averageFPS = fpsHistory.stream()
                    .mapToInt(Integer::intValue)
                    .average()
                    .orElse(60.0);
            
            lastFpsUpdate = currentTime;
        }
        
        updateCpuLoad();
    }
    
    private void updateCpuLoad() {
        double fpsLoad;
        if (currentFPS >= 55) {
            fpsLoad = 0.2;
        } else if (currentFPS >= 45) {
            fpsLoad = 0.7 + (45 - currentFPS) * 0.01;
        } else if (currentFPS >= 35) {
            fpsLoad = 0.8 + (35 - currentFPS) * 0.01;
        } else if (currentFPS >= 25) {
            fpsLoad = 0.9 + (25 - currentFPS) * 0.005;
        } else {
            fpsLoad = 0.98;
        }
        
        double frameTimeLoad = 0.0;
        if (frameTimeMs > TARGET_FRAME_TIME_MS) {
            double excess = (frameTimeMs - TARGET_FRAME_TIME_MS) / TARGET_FRAME_TIME_MS;
            frameTimeLoad = Math.min(1.0, excess);
        }
        
        double load = Math.max(fpsLoad, 0.7 * fpsLoad + 0.3 * frameTimeLoad);
        
        if (isStuttering && load < 0.85) {
            load = 0.85;
        }
        
        cpuLoad = Math.min(1.0, load);
    }
    
    public int getCurrentFPS() {
        return currentFPS;
    }
    
    public double getAverageFPS() {
        return averageFPS;
    }
    
    public double getFrameTimeMs() {
        return frameTimeMs;
    }
    
    public boolean isStuttering() {
        return isStuttering;
    }
    
    public double getCpuLoad() {
        return cpuLoad;
    }
    
    public boolean isCpuOverloaded() {
        return cpuLoad > 0.7 || currentFPS < 40;
    }
    
    public boolean isPerformanceCritical() {
        return cpuLoad > 0.9 || currentFPS < 25 || isStuttering;
    }
    
    public double getFrameTimeVariance() {
        if (frameTimeHistory.size() < 2) return 0.0;
        
        double mean = frameTimeHistory.stream()
                .mapToLong(Long::longValue)
                .average()
                .orElse(0.0);
        
        double variance = frameTimeHistory.stream()
                .mapToDouble(t -> Math.pow(t - mean, 2))
                .average()
                .orElse(0.0);
        
        return Math.sqrt(variance) / 1_000_000.0;
    }
    
    public String getPerformanceSummary() {
        return String.format("FPS: %d (avg: %.1f) | Frame: %.2fms | Load: %.0f%% | %s",
                currentFPS, averageFPS, frameTimeMs, cpuLoad * 100,
                isStuttering ? "STUTTERING" : "OK");
    }
}
