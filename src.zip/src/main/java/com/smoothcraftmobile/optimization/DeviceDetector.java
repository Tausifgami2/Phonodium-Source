package com.smoothcraftmobile.optimization;

import com.smoothcraftmobile.SmoothCraftMobileClient;
import org.lwjgl.opengl.GL11;

public class DeviceDetector {
    
    public enum DeviceProfile {
        LOW_END,
        MID_RANGE,
        HIGH_END
    }
    
    private DeviceProfile deviceProfile = DeviceProfile.MID_RANGE;
    private int cpuCores;
    private long availableMemoryMB;
    private long maxMemoryMB;
    private String gpuVendor = "Unknown";
    private String gpuRenderer = "Unknown";
    private boolean isMobileDevice = false;
    private boolean isLowEndGpu = false;
    
    public void detectDevice() {
        detectCpu();
        detectMemory();
        detectGpu();
        determineProfile();
        
        SmoothCraftMobileClient.LOGGER.info("=== Device Detection Results ===");
        SmoothCraftMobileClient.LOGGER.info("CPU Cores: {}", cpuCores);
        SmoothCraftMobileClient.LOGGER.info("Available Memory: {} MB", availableMemoryMB);
        SmoothCraftMobileClient.LOGGER.info("Max Memory: {} MB", maxMemoryMB);
        SmoothCraftMobileClient.LOGGER.info("GPU Vendor: {}", gpuVendor);
        SmoothCraftMobileClient.LOGGER.info("GPU Renderer: {}", gpuRenderer);
        SmoothCraftMobileClient.LOGGER.info("Mobile Device: {}", isMobileDevice);
        SmoothCraftMobileClient.LOGGER.info("Device Profile: {}", deviceProfile);
    }
    
    private void detectCpu() {
        cpuCores = Runtime.getRuntime().availableProcessors();
    }
    
    private void detectMemory() {
        Runtime runtime = Runtime.getRuntime();
        maxMemoryMB = runtime.maxMemory() / (1024 * 1024);
        availableMemoryMB = (runtime.maxMemory() - runtime.totalMemory() + runtime.freeMemory()) / (1024 * 1024);
    }
    
    private void detectGpu() {
        try {
            gpuVendor = GL11.glGetString(GL11.GL_VENDOR);
            gpuRenderer = GL11.glGetString(GL11.GL_RENDERER);
            
            if (gpuVendor == null) gpuVendor = "Unknown";
            if (gpuRenderer == null) gpuRenderer = "Unknown";
            
            String vendorLower = gpuVendor.toLowerCase();
            String rendererLower = gpuRenderer.toLowerCase();
            
            isMobileDevice = vendorLower.contains("qualcomm") ||
                    vendorLower.contains("arm") ||
                    vendorLower.contains("mali") ||
                    vendorLower.contains("adreno") ||
                    vendorLower.contains("powervr") ||
                    vendorLower.contains("imagination") ||
                    vendorLower.contains("mediatek") ||
                    rendererLower.contains("adreno") ||
                    rendererLower.contains("mali") ||
                    rendererLower.contains("powervr") ||
                    rendererLower.contains("tegra");
            
            isLowEndGpu = rendererLower.contains("intel hd") ||
                    rendererLower.contains("intel uhd") ||
                    rendererLower.contains("mesa") ||
                    rendererLower.contains("llvmpipe") ||
                    rendererLower.contains("software") ||
                    rendererLower.contains("swrast") ||
                    isMobileDevice;
            
        } catch (Exception e) {
            SmoothCraftMobileClient.LOGGER.warn("Failed to detect GPU info: {}", e.getMessage());
        }
    }
    
    private void determineProfile() {
        int score = 0;
        
        if (cpuCores >= 8) score += 3;
        else if (cpuCores >= 4) score += 2;
        else score += 1;
        
        if (maxMemoryMB >= 4096) score += 3;
        else if (maxMemoryMB >= 2048) score += 2;
        else score += 1;
        
        if (!isLowEndGpu && !isMobileDevice) score += 3;
        else if (!isLowEndGpu) score += 2;
        else score += 1;
        
        if (isMobileDevice) {
            score -= 2;
        }
        
        if (score >= 7) {
            deviceProfile = DeviceProfile.HIGH_END;
        } else if (score >= 4) {
            deviceProfile = DeviceProfile.MID_RANGE;
        } else {
            deviceProfile = DeviceProfile.LOW_END;
        }
    }
    
    public DeviceProfile getDeviceProfile() {
        return deviceProfile;
    }
    
    public int getCpuCores() {
        return cpuCores;
    }
    
    public long getAvailableMemoryMB() {
        Runtime runtime = Runtime.getRuntime();
        return (runtime.maxMemory() - runtime.totalMemory() + runtime.freeMemory()) / (1024 * 1024);
    }
    
    public long getMaxMemoryMB() {
        return maxMemoryMB;
    }
    
    public String getGpuVendor() {
        return gpuVendor;
    }
    
    public String getGpuRenderer() {
        return gpuRenderer;
    }
    
    public boolean isMobileDevice() {
        return isMobileDevice;
    }
    
    public boolean isLowEndGpu() {
        return isLowEndGpu;
    }
    
    public boolean shouldUseAggressiveOptimizations() {
        return deviceProfile == DeviceProfile.LOW_END || 
               isMobileDevice || 
               getAvailableMemoryMB() < 512;
    }
    
    public int getRecommendedRenderDistance() {
        return switch (deviceProfile) {
            case LOW_END -> 6;
            case MID_RANGE -> 10;
            case HIGH_END -> 16;
        };
    }
    
    public int getRecommendedEntityDistance() {
        return switch (deviceProfile) {
            case LOW_END -> 24;
            case MID_RANGE -> 32;
            case HIGH_END -> 48;
        };
    }
}
