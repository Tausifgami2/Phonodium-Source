package com.smoothcraftmobile.config;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public class ModMenuIntegration {
    
    public static Screen createConfigScreen(Screen parent) {
        return new ConfigScreen(parent);
    }
    
    public static boolean isModMenuInstalled() {
        return FabricLoader.getInstance().isModLoaded("modmenu");
    }
    
    public static void openConfigScreen() {
        MinecraftClient client = MinecraftClient.getInstance();
        client.setScreen(new ConfigScreen(client.currentScreen));
    }
}
