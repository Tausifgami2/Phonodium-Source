package com.smoothcraftmobile.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smoothcraftmobile.SmoothCraftMobileClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("smoothcraftmobile.json");
    
    private boolean chunkStreamingEnabled = true;
    private int chunkStreamRate = 2;
    private int maxChunkBuildsPerFrame = 4;
    
    private boolean entityCullingEnabled = true;
    private int entityCullingDistance = 32;
    private boolean animationThrottlingEnabled = true;
    private int animationThrottleDistance = 24;
    private int maxEntityUpdatesPerTick = 50;
    
    private boolean dynamicRenderDistanceEnabled = true;
    private int minRenderDistance = 4;
    private int maxRenderDistance = 16;
    private int targetFPS = 45;
    
    private boolean mobileAutoMode = true;
    private boolean showPerformanceOverlay = false;
    
    private boolean chunkCacheEnabled = true;
    private int maxCachedChunks = 256;
    
    public void load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                String json = Files.readString(CONFIG_PATH);
                ModConfig loaded = GSON.fromJson(json, ModConfig.class);
                copyFrom(loaded);
                SmoothCraftMobileClient.LOGGER.info("Config loaded from {}", CONFIG_PATH);
            } catch (IOException e) {
                SmoothCraftMobileClient.LOGGER.error("Failed to load config", e);
                save();
            }
        } else {
            save();
            SmoothCraftMobileClient.LOGGER.info("Created default config at {}", CONFIG_PATH);
        }
    }
    
    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(this));
        } catch (IOException e) {
            SmoothCraftMobileClient.LOGGER.error("Failed to save config", e);
        }
    }
    
    private void copyFrom(ModConfig other) {
        this.chunkStreamingEnabled = other.chunkStreamingEnabled;
        this.chunkStreamRate = other.chunkStreamRate;
        this.maxChunkBuildsPerFrame = other.maxChunkBuildsPerFrame;
        this.entityCullingEnabled = other.entityCullingEnabled;
        this.entityCullingDistance = other.entityCullingDistance;
        this.animationThrottlingEnabled = other.animationThrottlingEnabled;
        this.animationThrottleDistance = other.animationThrottleDistance;
        this.maxEntityUpdatesPerTick = other.maxEntityUpdatesPerTick;
        this.dynamicRenderDistanceEnabled = other.dynamicRenderDistanceEnabled;
        this.minRenderDistance = other.minRenderDistance;
        this.maxRenderDistance = other.maxRenderDistance;
        this.targetFPS = other.targetFPS;
        this.mobileAutoMode = other.mobileAutoMode;
        this.showPerformanceOverlay = other.showPerformanceOverlay;
        this.chunkCacheEnabled = other.chunkCacheEnabled;
        this.maxCachedChunks = other.maxCachedChunks;
    }
    
    public boolean isChunkStreamingEnabled() { return chunkStreamingEnabled; }
    public void setChunkStreamingEnabled(boolean enabled) { this.chunkStreamingEnabled = enabled; }
    
    public int getChunkStreamRate() { return chunkStreamRate; }
    public void setChunkStreamRate(int rate) { this.chunkStreamRate = rate; }
    
    public int getMaxChunkBuildsPerFrame() { return maxChunkBuildsPerFrame; }
    public void setMaxChunkBuildsPerFrame(int max) { this.maxChunkBuildsPerFrame = max; }
    
    public boolean isEntityCullingEnabled() { return entityCullingEnabled; }
    public void setEntityCullingEnabled(boolean enabled) { this.entityCullingEnabled = enabled; }
    
    public int getEntityCullingDistance() { return entityCullingDistance; }
    public void setEntityCullingDistance(int distance) { this.entityCullingDistance = distance; }
    
    public boolean isAnimationThrottlingEnabled() { return animationThrottlingEnabled; }
    public void setAnimationThrottlingEnabled(boolean enabled) { this.animationThrottlingEnabled = enabled; }
    
    public int getAnimationThrottleDistance() { return animationThrottleDistance; }
    public void setAnimationThrottleDistance(int distance) { this.animationThrottleDistance = distance; }
    
    public int getMaxEntityUpdatesPerTick() { return maxEntityUpdatesPerTick; }
    public void setMaxEntityUpdatesPerTick(int max) { this.maxEntityUpdatesPerTick = max; }
    
    public boolean isDynamicRenderDistanceEnabled() { return dynamicRenderDistanceEnabled; }
    public void setDynamicRenderDistanceEnabled(boolean enabled) { this.dynamicRenderDistanceEnabled = enabled; }
    
    public int getMinRenderDistance() { return minRenderDistance; }
    public void setMinRenderDistance(int distance) { this.minRenderDistance = distance; }
    
    public int getMaxRenderDistance() { return maxRenderDistance; }
    public void setMaxRenderDistance(int distance) { this.maxRenderDistance = distance; }
    
    public int getTargetFPS() { return targetFPS; }
    public void setTargetFPS(int fps) { this.targetFPS = fps; }
    
    public boolean isMobileAutoMode() { return mobileAutoMode; }
    public void setMobileAutoMode(boolean enabled) { this.mobileAutoMode = enabled; }
    
    public boolean isShowPerformanceOverlay() { return showPerformanceOverlay; }
    public void setShowPerformanceOverlay(boolean show) { this.showPerformanceOverlay = show; }
    
    public boolean isChunkCacheEnabled() { return chunkCacheEnabled; }
    public void setChunkCacheEnabled(boolean enabled) { this.chunkCacheEnabled = enabled; }
    
    public int getMaxCachedChunks() { return maxCachedChunks; }
    public void setMaxCachedChunks(int max) { this.maxCachedChunks = max; }
    
    public void resetCache() {
        SmoothCraftMobileClient.LOGGER.info("Chunk cache reset requested");
    }
}
