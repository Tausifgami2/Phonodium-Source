package com.smoothcraftmobile.config;

import com.smoothcraftmobile.SmoothCraftMobileClient;
import com.smoothcraftmobile.optimization.DeviceDetector;
import com.smoothcraftmobile.optimization.PerformanceMonitor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class ConfigScreen extends Screen {
    private final Screen parent;
    private final ModConfig config;
    
    private int scrollOffset = 0;
    private static final int ENTRY_HEIGHT = 24;
    private static final int MARGIN = 20;
    
    public ConfigScreen(Screen parent) {
        super(Text.literal("SmoothCraftMobile Settings"));
        this.parent = parent;
        this.config = SmoothCraftMobileClient.getInstance().getConfig();
    }
    
    @Override
    protected void init() {
        int centerX = this.width / 2;
        int y = 40;
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Chunk Streaming: " + (config.isChunkStreamingEnabled() ? "ON" : "OFF")),
                button -> {
                    config.setChunkStreamingEnabled(!config.isChunkStreamingEnabled());
                    button.setMessage(Text.literal("Chunk Streaming: " + (config.isChunkStreamingEnabled() ? "ON" : "OFF")));
                })
                .dimensions(centerX - 150, y, 300, 20)
                .build());
        y += ENTRY_HEIGHT;
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Entity Culling: " + (config.isEntityCullingEnabled() ? "ON" : "OFF")),
                button -> {
                    config.setEntityCullingEnabled(!config.isEntityCullingEnabled());
                    button.setMessage(Text.literal("Entity Culling: " + (config.isEntityCullingEnabled() ? "ON" : "OFF")));
                })
                .dimensions(centerX - 150, y, 300, 20)
                .build());
        y += ENTRY_HEIGHT;
        
        addDrawableChild(new IntSliderWidget(
                centerX - 150, y, 300, 20,
                Text.literal("Entity Culling Distance: " + config.getEntityCullingDistance()),
                config.getEntityCullingDistance(), 16, 64,
                value -> {
                    config.setEntityCullingDistance(value);
                    return Text.literal("Entity Culling Distance: " + value);
                }));
        y += ENTRY_HEIGHT;
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Animation Throttling: " + (config.isAnimationThrottlingEnabled() ? "ON" : "OFF")),
                button -> {
                    config.setAnimationThrottlingEnabled(!config.isAnimationThrottlingEnabled());
                    button.setMessage(Text.literal("Animation Throttling: " + (config.isAnimationThrottlingEnabled() ? "ON" : "OFF")));
                })
                .dimensions(centerX - 150, y, 300, 20)
                .build());
        y += ENTRY_HEIGHT;
        
        addDrawableChild(new IntSliderWidget(
                centerX - 150, y, 300, 20,
                Text.literal("Animation Throttle Distance: " + config.getAnimationThrottleDistance()),
                config.getAnimationThrottleDistance(), 8, 48,
                value -> {
                    config.setAnimationThrottleDistance(value);
                    return Text.literal("Animation Throttle Distance: " + value);
                }));
        y += ENTRY_HEIGHT;
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Dynamic Render Distance: " + (config.isDynamicRenderDistanceEnabled() ? "ON" : "OFF")),
                button -> {
                    config.setDynamicRenderDistanceEnabled(!config.isDynamicRenderDistanceEnabled());
                    button.setMessage(Text.literal("Dynamic Render Distance: " + (config.isDynamicRenderDistanceEnabled() ? "ON" : "OFF")));
                })
                .dimensions(centerX - 150, y, 300, 20)
                .build());
        y += ENTRY_HEIGHT;
        
        addDrawableChild(new IntSliderWidget(
                centerX - 150, y, 300, 20,
                Text.literal("Target FPS: " + config.getTargetFPS()),
                config.getTargetFPS(), 20, 120,
                value -> {
                    config.setTargetFPS(value);
                    return Text.literal("Target FPS: " + value);
                }));
        y += ENTRY_HEIGHT;
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Mobile Auto-Mode: " + (config.isMobileAutoMode() ? "ON" : "OFF")),
                button -> {
                    config.setMobileAutoMode(!config.isMobileAutoMode());
                    button.setMessage(Text.literal("Mobile Auto-Mode: " + (config.isMobileAutoMode() ? "ON" : "OFF")));
                })
                .dimensions(centerX - 150, y, 300, 20)
                .build());
        y += ENTRY_HEIGHT;
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Performance Overlay: " + (config.isShowPerformanceOverlay() ? "ON" : "OFF")),
                button -> {
                    config.setShowPerformanceOverlay(!config.isShowPerformanceOverlay());
                    button.setMessage(Text.literal("Performance Overlay: " + (config.isShowPerformanceOverlay() ? "ON" : "OFF")));
                })
                .dimensions(centerX - 150, y, 300, 20)
                .build());
        y += ENTRY_HEIGHT;
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Reset Chunk Cache"),
                button -> {
                    config.resetCache();
                })
                .dimensions(centerX - 150, y, 145, 20)
                .build());
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Apply Mobile Preset"),
                button -> {
                    SmoothCraftMobileClient.getInstance().getDeviceDetector().detectDevice();
                    this.clearAndInit();
                })
                .dimensions(centerX + 5, y, 145, 20)
                .build());
        y += ENTRY_HEIGHT + 10;
        
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Done"),
                button -> {
                    config.save();
                    close();
                })
                .dimensions(centerX - 75, this.height - 28, 150, 20)
                .build());
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 15, 0xFFFFFF);
        
        DeviceDetector detector = SmoothCraftMobileClient.getInstance().getDeviceDetector();
        PerformanceMonitor monitor = SmoothCraftMobileClient.getInstance().getPerformanceMonitor();
        
        String deviceInfo = String.format("Device: %s | GPU: %s", 
                detector.getDeviceProfile(), 
                detector.getGpuRenderer().substring(0, Math.min(30, detector.getGpuRenderer().length())));
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(deviceInfo), this.width / 2, this.height - 45, 0xAAAAAA);
        
        String perfInfo = monitor.getPerformanceSummary();
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(perfInfo), this.width / 2, this.height - 55, 0x88FF88);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    @Override
    public void close() {
        config.save();
        this.client.setScreen(parent);
    }
    
    private static class IntSliderWidget extends SliderWidget {
        private final int min;
        private final int max;
        private final java.util.function.IntFunction<Text> textProvider;
        
        public IntSliderWidget(int x, int y, int width, int height, Text text, 
                               int value, int min, int max, 
                               java.util.function.IntFunction<Text> textProvider) {
            super(x, y, width, height, text, (value - min) / (double) (max - min));
            this.min = min;
            this.max = max;
            this.textProvider = textProvider;
        }
        
        @Override
        protected void updateMessage() {
            setMessage(textProvider.apply(getValue()));
        }
        
        @Override
        protected void applyValue() {
            textProvider.apply(getValue());
        }
        
        public int getValue() {
            return (int) (this.value * (max - min) + min);
        }
    }
}
