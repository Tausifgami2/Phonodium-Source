package com.smoothcraftmobile;

import com.smoothcraftmobile.config.ModConfig;
import com.smoothcraftmobile.optimization.ChunkOptimizer;
import com.smoothcraftmobile.optimization.EntityOptimizer;
import com.smoothcraftmobile.optimization.DeviceDetector;
import com.smoothcraftmobile.optimization.PerformanceMonitor;
import com.smoothcraftmobile.optimization.DynamicRenderDistance;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SmoothCraftMobileClient implements ClientModInitializer {
    public static final String MOD_ID = "smoothcraftmobile";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    
    private static SmoothCraftMobileClient instance;
    private ModConfig config;
    private DeviceDetector deviceDetector;
    private ChunkOptimizer chunkOptimizer;
    private EntityOptimizer entityOptimizer;
    private PerformanceMonitor performanceMonitor;
    private DynamicRenderDistance dynamicRenderDistance;
    
    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("Initializing SmoothCraftMobile - Mobile Performance Optimizer");
        
        config = new ModConfig();
        config.load();
        
        deviceDetector = new DeviceDetector();
        deviceDetector.detectDevice();
        
        performanceMonitor = new PerformanceMonitor();
        chunkOptimizer = new ChunkOptimizer(config, performanceMonitor);
        entityOptimizer = new EntityOptimizer(config, performanceMonitor);
        dynamicRenderDistance = new DynamicRenderDistance(config, performanceMonitor, deviceDetector);
        
        if (config.isMobileAutoMode()) {
            applyMobileOptimizations();
        }
        
        registerEvents();
        
        LOGGER.info("SmoothCraftMobile initialized successfully!");
        LOGGER.info("Device Profile: {}", deviceDetector.getDeviceProfile());
    }
    
    private void registerEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world != null && client.player != null) {
                performanceMonitor.tick();
                
                if (config.isDynamicRenderDistanceEnabled()) {
                    dynamicRenderDistance.tick(client);
                }
                
                if (config.isChunkStreamingEnabled()) {
                    chunkOptimizer.tick(client);
                }
                
                if (config.isEntityCullingEnabled()) {
                    entityOptimizer.tick(client);
                }
            }
        });
    }
    
    private void applyMobileOptimizations() {
        DeviceDetector.DeviceProfile profile = deviceDetector.getDeviceProfile();
        
        switch (profile) {
            case LOW_END -> {
                config.setChunkStreamingEnabled(true);
                config.setEntityCullingEnabled(true);
                config.setEntityCullingDistance(24);
                config.setAnimationThrottlingEnabled(true);
                config.setAnimationThrottleDistance(16);
                config.setDynamicRenderDistanceEnabled(true);
                config.setTargetFPS(30);
                LOGGER.info("Applied LOW_END device optimizations");
            }
            case MID_RANGE -> {
                config.setChunkStreamingEnabled(true);
                config.setEntityCullingEnabled(true);
                config.setEntityCullingDistance(32);
                config.setAnimationThrottlingEnabled(true);
                config.setAnimationThrottleDistance(24);
                config.setDynamicRenderDistanceEnabled(true);
                config.setTargetFPS(45);
                LOGGER.info("Applied MID_RANGE device optimizations");
            }
            case HIGH_END -> {
                config.setChunkStreamingEnabled(true);
                config.setEntityCullingEnabled(true);
                config.setEntityCullingDistance(48);
                config.setAnimationThrottlingEnabled(false);
                config.setDynamicRenderDistanceEnabled(false);
                config.setTargetFPS(60);
                LOGGER.info("Applied HIGH_END device optimizations");
            }
        }
        
        config.save();
    }
    
    public static SmoothCraftMobileClient getInstance() {
        return instance;
    }
    
    public ModConfig getConfig() {
        return config;
    }
    
    public DeviceDetector getDeviceDetector() {
        return deviceDetector;
    }
    
    public ChunkOptimizer getChunkOptimizer() {
        return chunkOptimizer;
    }
    
    public EntityOptimizer getEntityOptimizer() {
        return entityOptimizer;
    }
    
    public PerformanceMonitor getPerformanceMonitor() {
        return performanceMonitor;
    }
    
    public DynamicRenderDistance getDynamicRenderDistance() {
        return dynamicRenderDistance;
    }
}
